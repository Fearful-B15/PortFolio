//start of the javascript 
$(document).ready(function() {
    //The onclick function when the users clicks the button it adds -1
    $('.minus-btn').on('click', function(e) {
        e.preventDefault();
        var $this = $(this);
        var $input = $this.siblings('input');
        var value = parseInt($input.val());
        if (value > 0) {
            value = value - 1;
        } else {
            value = 0;
        }

        $input.val(value);
    });
//The onclick function when the users clicks the button it adds +1
    $('.plus-btn').on('click', function(e) {
        e.preventDefault();
        var $this = $(this);
        var $input = $this.siblings('input');
        var value = parseInt($input.val());

        if (value < 25) {
            value = value + 1;
        } else {
            value = 25;
        }
        $input.val(value);
    });
});
