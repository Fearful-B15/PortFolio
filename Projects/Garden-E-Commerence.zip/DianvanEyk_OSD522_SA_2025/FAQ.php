<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FAQ - Heckers Garden Centre</title>
    <link rel="stylesheet" href="CSS/styles.css">
    <style>
        .faq-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .faq-title {
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            color: #15472c;
            margin-bottom: 25px;
        }

        .faq-item {
            margin-bottom: 20px;
        }

        .faq-item h3 {
            font-size: 20px;
            color: #0b4d12;
            cursor: pointer;
            margin-bottom: 5px;
        }

        .faq-item p {
            font-size: 16px;
            margin-left: 15px;
            display: none;
            line-height: 1.5;
        }
    </style>
</head>
<body>

<div class="faq-container">
    <img src="Media/HeckersGardenLogo.png" alt="Heckers Garden Centre Logo" class="logo">
    <div class="faq-title">Frequently Asked Questions</div>

    <div class="faq-item">
        <h3>Q1: Do you offer delivery services?</h3>
        <p>A: Yes! We deliver plants, accessories, and compost to your doorstep. Delivery times vary depending on your location.</p>
    </div>

    <div class="faq-item">
        <h3>Q2: Are your plants pet-friendly?</h3>
        <p>A: Most of our plants are safe for pets, but we recommend checking individual plant details before purchase.</p>
    </div>

    <div class="faq-item">
        <h3>Q3: Can I return an item if I'm not satisfied?</h3>
        <p>A: Yes, we offer a 14-day return policy on most products. Please retain your receipt and ensure the item is in good condition.</p>
    </div>

    <div class="faq-item">
        <h3>Q4: Do you offer bulk discounts?</h3>
        <p>A: Yes! For bulk orders, please contact us directly via the contact form for a custom quote.</p>
    </div>

    <div class="faq-item">
        <h3>Q5: How can I track my order?</h3>
        <p>A: Once your order has been shipped, we will provide a tracking number via email.</p>
    </div>
    <a href="Index.php" class="back-btn">Back to Home</a>
</div>

<script>
    // Toggle answer display for the FAQ items
    const faqs = document.querySelectorAll('.faq-item h3');
    faqs.forEach(faq => {
        faq.addEventListener('click', () => {
            const answer = faq.nextElementSibling;
            answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
        });
    });
</script>

</body>
</html>
