<?php
session_start();

// Initialize cart
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle Add to Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $productId = intval($_POST['product_id']);
    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId]++;
    } else {
        $_SESSION['cart'][$productId] = 1;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Store - Heckers Garden Centre</title>
<link rel="stylesheet" href="CSS/styles.css">
<style>
/* Layout */
.store-container {
    display: flex;
    max-width: 1300px;
    margin: 20px auto;
    gap: 20px;
    padding: 10px;
}

/* Filter Sidebar */
.filter-sidebar {
    width: 220px;
    background: #15472c;
    color: white;
    padding: 20px;
    border-radius: 6px;
    height: fit-content;
}
.filter-sidebar h3 { margin-bottom: 15px; }
.filter-sidebar button {
    width: 100%;
    padding: 10px;
    margin: 5px 0;
    background: #0e351f;
    border: none;
    color: white;
    font-weight: bold;
    border-radius: 4px;
    cursor: pointer;
}
.filter-sidebar button:hover { background: #092617; }

/* Product Grid */
.book-grid {
    flex-grow: 1;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 20px;
}
.book {
    width: 100%;
    height: 320px;
    border-radius: 6px;
    overflow: hidden;
    background: white;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    position: relative;
    display: flex;
    flex-direction: column;
}
.book img {
    width: 100%;
    height: 225px;
    object-fit: cover;
}
.addcart-btn {
    margin-bottom: auto;
    height: 100px;
    width: 100%;
    padding: 10px;
    background: #28a745;
    color: white;
    font-weight: bold;
    border: none;
    cursor: pointer;
    border-radius: 0 0 6px 6px;
    font-size: 28px;
}
.addcart-btn:hover {
    background: #1e7a34;
 }

/* Responsive */
@media (max-width: 900px) {
    .store-container 
    { flex-direction: column; 
    }
    .filter-sidebar {
         width: 100%;
          text-align: center; }
    .filter-sidebar button { 
        width: 100%; }
}

/* Cart Button */
.cart-btn {
    display: inline-block;
    background: #15472c;
    color: white;
    padding: 8px 15px;
    border-radius: 4px;
    font-weight: bold;
    text-decoration: none;

}
.cart-btn:hover { 
    background: #0e351f; 
    }
</style>
</head>
<body>

<header class="header">
    <img src="Media/HeckersGardenLogo.png" alt="Heckers Garden Centre Logo" class="logo">
    <h1>Heckers Garden Centre - Store</h1>
    <div class="welcome-user">
        <a class="cart-btn" href="cart.php">Cart (<?= array_sum($_SESSION['cart']) ?>)</a>
        <a class="cart-btn" href="Index.php">Home</a> 
    </div>
</header>


<div class="store-container">

    <!-- Left Sidebar -->
    <div class="filter-sidebar">
        <h3>Filter by Category</h3>
        <button onclick="filterItems('all')">All</button>
        <button onclick="filterItems('Plant')">Plant</button>
        <button onclick="filterItems('Accessory')">Accessory</button>
        <button onclick="filterItems('Compost')">Compost</button>
    </div>

    <!-- Product Grid -->
    <div class="book-grid">

        <!-- Plant Category -->
        <div class="book" data-category="Plant">
            <a href="Rose.php">
                <img src="Media/rose_bush.jpg" alt="Rose Bush" style="border-radius:6px;">
            </a>
            <form method="post">
                <input type="hidden" name="product_id" value="1">
                <button class="addcart-btn">Add to Cart</button>
            </form>
        </div>

        <div class="book" data-category="Plant">
            <a href="Tomato.php">
                <img src="Media/tomato_seedling.jpg" alt="Tomato Seedling" style="border-radius:6px;">
            </a>
            <form method="post">
                <input type="hidden" name="product_id" value="2">
                <button class="addcart-btn">Add to Cart</button>
            </form>
        </div>

        <!-- Accessory Category -->
        <div class="book" data-category="Accessory">
            <a href="watering_can.php">
                <img src="Media/watering_can.jpg" alt="Watering Can" style="border-radius:6px;">
            </a>
            <form method="post">
                <input type="hidden" name="product_id" value="3">
                <button class="addcart-btn">Add to Cart</button>
            </form>
        </div>

        <div class="book" data-category="Accessory">
            <a href="4. Garden_gloves.php">
                <img src="Media/garden_gloves.jpg" alt="Garden Gloves" style="border-radius:6px;">
            </a>
            <form method="post">
                <input type="hidden" name="product_id" value="4">
                <button class="addcart-btn">Add to Cart</button>
            </form>
        </div>

        <!-- Compost Category -->
        <div class="book" data-category="Compost">
            <a href="Organic_compost.php">
                <img src="Media/organic_compost.jpg" alt="Organic Compost" style="border-radius:6px;">
            </a>
            <form method="post">
                <input type="hidden" name="product_id" value="5">
                <button class="addcart-btn">Add to Cart</button>
            </form>
        </div>
                <div class="book" data-category="Compost">
            <a href="Multi-Purpose_compost.php">
                <img src="Media/multi_purpose_compost.jpg" alt="Multi-Purposet" style="border-radius:6px;">
            </a>
            <form method="post">
                <input type="hidden" name="product_id" value="6">
                <button class="addcart-btn">Add to Cart</button>
            </form>
        </div>

    </div>

</div>

<script>
function filterItems(category) {
    const items = document.querySelectorAll('.book');
    items.forEach(item => {
        if(category === 'all' || item.dataset.category === category) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}
</script>

</body>
</html>
