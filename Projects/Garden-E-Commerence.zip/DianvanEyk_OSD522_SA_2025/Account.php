<?php
session_start();

// If user is NOT logged in, send them away
if (!isset($_SESSION["username"]) || !isset($_SESSION["user_id"])) {;
    exit();
}

$username = $_SESSION["username"];
$userID = $_SESSION["user_id"]; // store this during login

// DB Connection
$conn = new mysqli("localhost", "root", "", "garden");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }


?>

<!DOCTYPE html>
<html>
<head>
    <title>My Account</title>
    <link rel="stylesheet" href="CSS/styles.css">

    <style>
        .account-container {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
        }

        .account-title {
            text-align: center;
            font-size: 30px;
            color: #15472c;
            margin-bottom: 25px;
            font-weight: bold;
        }

        .info-box {
            background: #f0f4ef;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 5px solid #15472c;
        }

        .info-box span {
            font-weight: bold;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th, td {
            border: 1px solid #15472c;
            padding: 12px;
        }

        th {
            background: #15472c;
            color: white;
        }

        .no-orders {
            text-align: center;
            padding: 15px;
            font-size: 18px;
            color: #444;
        }

        .back-btn {
            background: #15472c;
            color: white;
            padding: 10px 18px;
            border: none;
            font-weight: bold;
            border-radius: 6px;
            margin-top: 20px;
            cursor: pointer;
            display: block;
            width: 200px;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>

<body>

<div class="account-container">

    <div class="account-title">My Account</div>

    <!-- USER DETAILS -->
    <div class="info-box">
        <p><span>Account Name:</span> <?= htmlspecialchars($username) ?></p>
        <p><span>Password:</span> ******** </p>
    </div>

    <!-- ORDER HISTORY -->
    <h3 style="color:#15472c;">Previous Orders</h3>

    <?php if ($orderResult->num_rows > 0): ?>
    <table>
        <tr>
            <th>Order ID</th>
            <th>Total</th>
            <th>Date</th>
        </tr>

        <?php while ($order = $orderResult->fetch_assoc()): ?>
            <tr>
                <td><?= $order['ID'] ?></td>
                <td>R<?= number_format($order['Total'], 2) ?></td>
                <td><?= $order['DateOrdered'] ?></td>
            </tr>
        <?php endwhile; ?>

    </table>

    <?php else: ?>
        <div class="no-orders">You have no previous orders.</div>
    <?php endif; ?>

    <a href="index.php"><button class="back-btn">Back to Home</button></a>

</div>

</body>
</html>
