-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2025 at 09:15 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `garden`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Subject` varchar(255) NOT NULL,
  `Message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`ID`, `Name`, `Email`, `Subject`, `Message`) VALUES
(1, 'Dian Rohen Van Eyk', 'dian.vaneyk2003@gmail.com', 'Deliveries ', 'How long do deliveries take '),
(2, 'Dian Rohen Van Eyk', 'dian.vaneyk2003@gmail.com', 'Deliveries ', 'How long do deliveries take '),
(3, 'Dian Rohen Van Eyk', 'dian.vaneyk2003@gmail.com', 'Deliveries ', 'How long do deliveries take '),
(4, 'Dian Rohen Van Eyk', 'dian.vaneyk2003@gmail.com', 'Missing Plants', 'When are you guys getting Venus flytraps '),
(5, 'Dian Rohen Van Eyk', 'dian.vaneyk2003@gmail.com', 'Missing Plants', 'Hello ');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `ID` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`ID`, `UserName`, `password`, `Email`) VALUES
(0, 'E001', '$2y$10$EqLg1eaXMlrMIzSaXscwzOh04KHqPjWh4G5ct8/j5yp5EE3PuSwUq', ''),
(0, 'Dev05', '$2y$10$J0j5Lx6NLlFssLXe1.bov.rd.L.T9BXU7QLhY.jLveBbM1eiPOUxy', ''),
(0, 'John', '$2y$10$Xb7vxu35nroKwd59z13yyOolv6zNQXa0EJzUsfDhcf2goffXgyhw6', ''),
(0, 'DianRohenvanEyk', '$2y$10$QjKcAYhiYv.X1wPzecOKEuNV90qiQDCrR7gyG4mqQ1lLLUWwW3DES', ''),
(0, 'Floyd', '$2y$10$pb/0S9ZaKoXEY72y1VQ81emIJXwIsHFqueKtUTSh6dP6ex8KAiIhy', '');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `ID` int(11) NOT NULL,
  `ItemName` varchar(255) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Quantity` int(11) NOT NULL DEFAULT 0,
  `Price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`ID`, `ItemName`, `Category`, `Quantity`, `Price`) VALUES
(1, 'Rose Bush', 'Plant', 5, 89.99),
(2, 'Tomato Seedling', 'Plant', 14, 29.99),
(3, 'Watering Can', 'Accessory', 14, 149.99),
(4, 'Garden Gloves', 'Accessory', 24, 59.99),
(5, 'Organic Compost', 'Compost', 26, 79.99),
(6, 'Multi-Purpose Compost', 'Compost', 49, 120.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
