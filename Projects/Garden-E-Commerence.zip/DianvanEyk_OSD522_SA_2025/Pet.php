<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Pet-Friendly Plants</title>
    <link rel="stylesheet" href="CSS/styles.css">

    <style>
        .pet-container {
            max-width: 900px;
            margin: 40px auto;
            background: #ffffff;
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            text-align: center;
        }

        .pet-banner {
            background: #15472c;
            color: white;
            padding: 20px;
            border-radius: 10px;
            font-size: 26px;
            font-weight: bold;
            margin-bottom: 25px;
        }

        .pet-info {
            font-size: 16px;
            margin-bottom: 25px;
            color: #222;
        }

        .pet-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
            gap: 20px;
        }

        .pet-card {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
            transition: 0.3s;
        }

        .pet-card:hover {
            transform: scale(1.04);
        }

        .pet-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 8px;
            color: #15472c;
        }

        .pet-safe {
            padding: 8px 14px;
            background: #28a745;
            color: white;
            border-radius: 5px;
            font-size: 12px;
            margin-bottom: 10px;
            display: inline-block;
        }

        .pet-toxic {
            padding: 8px 14px;
            background: #b30000;
            color: white;
            border-radius: 5px;
            font-size: 12px;
            margin-bottom: 10px;
            display: inline-block;
        }

        .pet-details {
            font-size: 14px;
            color: #333;
        }

        .pet-btn {
            margin-top: 30px;
            padding: 10px 20px;
            background: #15472c;
            color: white;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-weight: bold;
        }

        .pet-btn:hover {
            background: #066e31;
        }

        /* Toxic warning section */
        .warning-box {
            background: #ffe6e6;
            padding: 20px;
            border-left: 6px solid #b30000;
            border-radius: 6px;
            margin-top: 35px;
            text-align: left;
        }

        .warning-title {
            font-size: 20px;
            color: #b30000;
            font-weight: bold;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

<div class="pet-container">
<img src="Media/HeckersGardenLogo.png" alt="Heckers Garden Centre Logo" class="logo">
    <div class="pet-banner">Pet-Friendly Plants</div>

    <p class="pet-info">
        These plants are **safe for pets** such as cats and dogs.  
        Perfect for households that want greenery without risk!
    </p>

    <div class="pet-grid">

        <div class="pet-card">
            <div class="pet-title">Areca Palm</div>
            <div class="pet-safe">✓ Safe for Pets</div>
            <div class="pet-details">A beautiful indoor palm that won't harm cats or dogs.</div>
        </div>

        <div class="pet-card">
            <div class="pet-title">Spider Plant</div>
            <div class="pet-safe">✓ Safe for Pets</div>
            <div class="pet-details">Air-purifying, hardy, and totally non-toxic to pets.</div>
        </div>

        <div class="pet-card">
            <div class="pet-title">Boston Fern</div>
            <div class="pet-safe">✓ Safe for Pets</div>
            <div class="pet-details">A lush green fern safe for both dogs and cats.</div>
        </div>

        <div class="pet-card">
            <div class="pet-title">Calathea</div>
            <div class="pet-safe">✓ Safe for Pets</div>
            <div class="pet-details">Colorful tropical leaves that are completely pet-friendly.</div>
        </div>

    </div>

    <!-- Toxic Plant Warning Section -->
    <div class="warning-box">
        <div class="warning-title">Plants to Avoid Around Pets</div>
        <p><strong>These plants can be toxic to cats and dogs:</strong></p>
        <ul>
            <li>Lilies</li>
            <li>Aloe Vera</li>
            <li>Pothos / Money Plant</li>
            <li>Peace Lily</li>
            <li>Sago Palm</li>
        </ul>
        <p>If your pet eats a plant and shows symptoms, contact a vet immediately.</p>
    </div>

    <br><br>
    <a href="Index.php"><button class="pet-btn">Back to Home</button></a>

</div>

</body>
</html>
