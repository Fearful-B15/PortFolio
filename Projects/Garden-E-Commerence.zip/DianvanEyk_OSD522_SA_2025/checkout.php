<?php
session_start();

// Check if cart is empty
$empty = (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0);

// Database connection
$conn = new mysqli("localhost", "root", "", "garden");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

// Get cart items
$items = [];
$total = 0;

if (!$empty) {
    foreach ($_SESSION['cart'] as $id => $qty) {
        $stmt = $conn->prepare("SELECT * FROM stock WHERE ID = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        $row["qty"] = $qty;
        $row["subtotal"] = $qty * $row["Price"];
        $total += $row["subtotal"];
        $items[] = $row;
    }
}

// Handle order submission
$orderSuccess = false;
$orderError = '';
if (isset($_POST['place_order'])) {
    $name = htmlspecialchars($_POST['name']);
    $address = htmlspecialchars($_POST['address']);
    $contact = htmlspecialchars($_POST['contact']);
    $cardNumber = htmlspecialchars($_POST['card_number']);
    $expiry = htmlspecialchars($_POST['expiry']);
    $cvv = htmlspecialchars($_POST['cvv']);

    // Basic card validation (simple check)
    if (!preg_match('/^\d{16}$/', $cardNumber)) {
        $orderError = "Invalid credit card number.";
    } elseif (!preg_match('/^\d{2}\/\d{2}$/', $expiry)) {
        $orderError = "Invalid expiry date format. Use MM/YY.";
    } elseif (!preg_match('/^\d{3}$/', $cvv)) {
        $orderError = "Invalid CVV.";
    } else {
        // Subtract quantities from stock
        foreach ($_SESSION['cart'] as $id => $qty) {
            $stmt = $conn->prepare("UPDATE stock SET Quantity = Quantity - ? WHERE ID = ? AND Quantity >= ?");
            $stmt->bind_param("iii", $qty, $id, $qty);
            $stmt->execute();
        }

        // Clear cart and mark order success
        $_SESSION['cart'] = [];
        $orderSuccess = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Checkout - Heckers Garden Centre</title>
<link rel="stylesheet" href="CSS/styles.css">
<style>
.checkout-container {
    max-width: 900px;
    margin: 20px auto;
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
    border: 2px solid #222;
}
.checkout-container h2 {
    text-align: center;
}
.stock-table th, .stock-table td {
    padding: 10px;
    text-align: left;
}
.delivery-form {
    margin-top: 20px;
}
.delivery-form label {
    display: block;
    margin-top: 10px;
    font-weight: bold;
}
.delivery-form input,
.delivery-form textarea {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border-radius: 4px;
    border: 1px solid #222;
}
.delivery-form button {
    margin-top: 15px;
    padding: 10px 15px;
    background: #D84E72;
    color: white;
    border-radius: 4px;
    border: none;
    cursor: pointer;
    font-weight: bold;
}
.delivery-form button:hover {
    opacity: 0.9;
}
.message {
    text-align: center;
    color: #9C5FA4;
    font-weight: bold;
    margin-bottom: 15px;
}
.update {
    display: block;
    margin: 20px auto;
    padding: 10px 20px;
    background: #15472c;
    color: white;
    border: none;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
}
.update:hover {
    background: #0e351f;
}
.error {
    text-align:center;
    color:red;
    font-weight:bold;
}
</style>
</head>
<body>

<div class="checkout-container">
<h2>Checkout</h2>

<?php if ($orderSuccess): ?>
    <p class="message">Thank you, your order has been placed successfully! It will be delivered to the address provided.</p>
    <a href="store.php"><button class="update">Back to Store</button></a>
<?php elseif ($empty): ?>
    <p>Your cart is empty.</p>
    <a href="store.php"><button class="update">Back to Store</button></a>
<?php else: ?>

<?php if ($orderError): ?>
    <p class="error"><?= $orderError ?></p>
<?php endif; ?>

<h3>Order Summary</h3>
<table class="stock-table">
<tr>
    <th>Item</th>
    <th>Price</th>
    <th>Qty</th>
    <th>Subtotal</th>
</tr>
<?php foreach ($items as $item): ?>
<tr>
    <td><?= htmlspecialchars($item['ItemName']) ?></td>
    <td>R<?= number_format($item['Price'],2) ?></td>
    <td><?= $item['qty'] ?></td>
    <td>R<?= number_format($item['subtotal'],2) ?></td>
</tr>
<?php endforeach; ?>
<tr>
    <th colspan="3">Total</th>
    <th>R<?= number_format($total,2) ?></th>
</tr>
</table>

<h3>Delivery & Payment Information</h3>
<form method="post" class="delivery-form">
    <label for="name">Full Name</label>
    <input type="text" name="name" id="name" required>

    <label for="address">Delivery Address</label>
    <textarea name="address" id="address" rows="3" required></textarea>

    <label for="contact">Contact Number</label>
    <input type="text" name="contact" id="contact" required>

    <label for="card_number">Credit Card Number</label>
    <input type="text" name="card_number" id="card_number" maxlength="16" required>

    <label for="expiry">Expiry Date (MM/YY)</label>
    <input type="text" name="expiry" id="expiry" placeholder="MM/YY" required>

    <label for="cvv">CVV</label>
    <input type="text" name="cvv" id="cvv" maxlength="3" required>

    <button type="submit" name="place_order">Place Order</button>
</form>

<?php endif; ?>
</div>

</body>
</html>
