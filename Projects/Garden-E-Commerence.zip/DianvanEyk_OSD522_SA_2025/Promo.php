<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Special Promotions</title>
    <link rel="stylesheet" href="CSS/styles.css">

    <style>
        /* Page container */
        .promo-container {
            max-width: 900px;
            margin: 40px auto;
            background: #ffffff;
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            text-align: center;
        }

        /* Promo banner */
        .promo-banner {
            background: #15472c;
            color: white;
            padding: 20px;
            border-radius: 10px;
            font-size: 26px;
            font-weight: bold;
            margin-bottom: 30px;
        }

        /* Grid of promotions */
        .promo-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
            gap: 20px;
        }

        .promo-box {
            background: #f3f3f3;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
            transition: 0.3s;
        }

        .promo-box:hover {
            transform: scale(1.04);
        }

        .promo-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 12px;
        }

        .promo-details {
            font-size: 14px;
            margin-bottom: 15px;
        }

        .promo-btn {
            padding: 10px 20px;
            background: #15472c;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }

        .promo-btn:hover {
            background: #066e31;
        }
    </style>
</head>

<body>

<div class="promo-container">
<img src="Media/HeckersGardenLogo.png" alt="Heckers Garden Centre Logo" class="logo">
    <div class="promo-banner">
        Special Garden Promotions & Deals 
    </div>

    <p>Save big on plants, compost, and gardening accessories!  
       Offers available for a limited time only.</p>

    <div class="promo-grid">

        <div class="promo-box">
            <div class="promo-title"> 20% OFF All Flowering Plants</div>
            <div class="promo-details">Roses, lilies, orchids & more.</div>
            <a href="store.php"><button class="promo-btn">Shop Now</button></a>
        </div>

        <div class="promo-box">
            <div class="promo-title"> Buy 2, Get 1 Free  Seedlings</div>
            <div class="promo-details">Vegetable + herb starter kits.</div>
            <a href="store.php"><button class="promo-btn">Shop Now</button></a>
        </div>

        <div class="promo-box">
            <div class="promo-title"> 15% OFF Garden Accessories</div>
            <div class="promo-details">Gloves, tools, watering cans.</div>
            <a href="store.php"><button class="promo-btn">Shop Now</button></a>
        </div>

    </div>

    <br><br>
    <a href="index.php"><button class="promo-btn">Back to Home</button></a>

</div>

</body>
</html>
