<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['cart'][3] = ($_SESSION['cart'][3] ?? 0) + 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Watering Can - Heckers Garden Centre</title>
<link rel="stylesheet" href="CSS/styles.css">
</head>
<body>

<a class="back-btn" href="store.php">⬅ Back to Store</a>

<div class="product-page">
    <img src="Media/watering_can.jpg" class="product-image" alt="Watering Can">
    <h1>Watering Can</h1>
    <p>Durable metal watering can for everyday garden use.</p>
    <p><strong>Price: R230</strong></p>

    <form method="post">
        <button class="addcart-btn">Add to Cart</button>
    </form>
</div>

</body>
</html>
