<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['cart'][5] = ($_SESSION['cart'][5] ?? 0) + 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Organic Compost - Heckers Garden Centre</title>
<link rel="stylesheet" href="CSS/styles.css">
</head>
<body>

<a class="back-btn" href="store.php">⬅ Back to Store</a>

<div class="product-page">
    <img src="Media/organic_compost.jpg" class="product-image" alt="Organic Compost">
    <h1>Organic Compost</h1>
    <p>Premium organic compost to help your plants thrive.</p>
    <p><strong>Price: R175</strong></p>


    <form method="post">
        <button class="addcart-btn">Add to Cart</button>
    </form>
</div>

</body>
</html>
