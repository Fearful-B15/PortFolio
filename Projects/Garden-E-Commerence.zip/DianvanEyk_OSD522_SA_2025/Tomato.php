<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['cart'][2] = ($_SESSION['cart'][2] ?? 0) + 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Tomato Seedling - Heckers Garden Centre</title>
<link rel="stylesheet" href="CSS/styles.css">
</head>
<body>

<a class="back-btn" href="store.php">⬅ Back to Store</a>

<div class="product-page">
    <img src="Media/tomato_seedling.jpg" class="product-image" alt="Tomato Seedling">
    <h1>Tomato Seedling</h1>
    <p>A healthy tomato seedling ready to be planted.</p>
    <p><strong>Price: R90</strong></p>


    <form method="post">
        <button class="addcart-btn">Add to Cart</button>
    </form>
</div>

</body>
</html>
