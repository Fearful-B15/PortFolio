<?php
session_start();

// If cart empty
$empty = (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0);

// Database
$conn = new mysqli("localhost", "root", "", "garden");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

// Update quantities safely
if (isset($_POST['update']) && isset($_POST['qty']) && is_array($_POST['qty'])) {
    foreach ($_POST['qty'] as $id => $qty) {
        $qty = intval($qty);
        if ($qty <= 0) {
            unset($_SESSION['cart'][$id]);
        } else {
            $_SESSION['cart'][$id] = $qty;
        }
    }
}

// Remove item
if (isset($_GET['remove'])) {
    unset($_SESSION['cart'][$_GET['remove']]);
}

// Get cart data
$items = [];
$total = 0;

if (!$empty) {
    foreach ($_SESSION['cart'] as $id => $qty) {
        $stmt = $conn->prepare("SELECT * FROM stock WHERE ID = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        $row["qty"] = $qty;
        $row["subtotal"] = $qty * $row["Price"];
        $total += $row["subtotal"];
        $items[] = $row;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Your Cart</title>
<link rel="stylesheet" href="CSS/styles.css">
<style>
/* Centered container for the cart section */
.checkout-container {
    max-width: 900px;
    margin: 30px auto; 
    background: #ffffff;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

/* Default Layout Styles (if not already in your external CSS) */
table { 
    width: 100%;
    border-collapse: collapse;
}
th, td { 
    padding: 12px; 
    border-bottom: 1px solid #ccc; 
}
button {
     padding: 10px 14px; 
     cursor: pointer; 
     border:none; 
     border-radius:5px;
     font-weight: bold;
     background:#D35070;
}
.update { 
    background:#15472c; 
    color:white; }
.remove { 
    background:#b30000; 
    color:white; }
.checkout { 
    background:#28a745; 
    color:white; 
    margin-top:20px; }
</style>
</head>
<body>

<h2 style="text-align:center; margin-top:20px;">Your Shopping Cart</h2>

<div class="checkout-container">

<?php if ($empty): ?>

<p>Your cart is empty.</p>
<a href="store.php"><button class="update">Back to Store</button></a>

<?php else: ?>

<form method="post">

<table>
<tr>
    <th>Item</th>
    <th>Price</th>
    <th>Qty</th>
    <th>Subtotal</th>
    <th></th>
</tr>

<?php foreach ($items as $item): ?>
<tr>
    <td><?= htmlspecialchars($item['ItemName']) ?></td>
    <td>R<?= number_format($item['Price'],2) ?></td>

    <td>
        <input type="number" name="qty[<?= $item['ID'] ?>]" 
               value="<?= $item['qty'] ?>" min="1" style="width:60px;">
    </td>

    <td>R<?= number_format($item['subtotal'],2) ?></td>

    <td>
        <a href="cart.php?remove=<?= $item['ID'] ?>">
            <button type="button" class="remove">Remove</button>
        </a>
    </td>
</tr>
<?php endforeach; ?>

</table>

<button type="submit" name="update" class="update">Update Cart</button>

</form>

<h3 style="margin-top:20px;">Total: R<?= number_format($total, 2) ?></h3>

<a href="checkout.php">
    <button class="checkout">Proceed to Checkout</button>
</a>

<?php endif; ?>

</div>

</body>
</html>
