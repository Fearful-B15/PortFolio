<?php
session_start();

// Success message after form submission
$sent = false;

// Database connection
$conn = new mysqli("localhost", "root", "", "garden");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission on the same page
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["name"])) {
    // Sanitize inputs
    $name = $conn->real_escape_string($_POST["name"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $subject = $conn->real_escape_string($_POST["subject"]);
    $message = $conn->real_escape_string($_POST["message"]);

    // Insert into database
    $sql = "INSERT INTO contact_messages (Name, Email, Subject, Message) 
            VALUES ('$name', '$email', '$subject', '$message')";

    if ($conn->query($sql)) {
        $sent = true;
    } else {
        echo "Error: " . $conn->error;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Contact Us - Heckers Garden Centre</title>
    <link rel="stylesheet" href="CSS/styles.css">

    <style>
        .contact-container {
            max-width: 700px;
            margin: 40px auto;
            padding: 35px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .contact-title {
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            color: #15472c;
            margin-bottom: 10px;
        }

        .contact-description {
            text-align: center;
            font-size: 16px;
            color: #333;
            margin-bottom: 25px;
            line-height: 1.5;
        }

        .contact-form label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
        }

        .contact-form input,
        .contact-form textarea {
            width: 100%;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #aaa;
            font-size: 16px;
            margin-top: 6px;
        }

        textarea {
            height: 130px;
            resize: none;
        }

        .contact-submit {
            margin-top: 20px;
            padding: 12px 20px;
            background: #15472c;
            color: white;
            cursor: pointer;
            border-radius: 6px;
            border: none;
            font-size: 17px;
            font-weight: bold;
            width: 100%;
        }

        .contact-submit:hover {
            background: #0d3c22;
        }

        .success-box {
            padding: 12px;
            background: #d4f8d4;
            border: 1px solid #4caf50;
            color: #0d3c22;
            font-weight: bold;
            text-align: center;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .back-btn {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 15px;
            background: #15472c;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }
        .back-btn:hover {
            background: #0d3c22;
        }
    </style>
</head>

<body>

<div class="contact-container">
    <img src="Media/HeckersGardenLogo.png" alt="Heckers Garden Centre Logo" class="logo">

    <div class="contact-title">Contact Us</div>

    <div class="contact-description">
        Heckers Garden Centre is your local destination for high-quality plants, gardening supplies, and pet essentials.
        We are passionate about helping you create and maintain your perfect garden. Reach out to us with your questions, 
        suggestions, or feedback and our friendly team will respond promptly.
    </div>

    <?php if ($sent): ?>
        <div class="success-box">
             Your message has been sent! We will get back to you as soon as possible.
        </div>
    <?php endif; ?>

    <!-- Form submits to the same page -->
    <form class="contact-form" method="POST" action="">
        <label>Your Name</label>
        <input type="text" name="name" required>

        <label>Your Email</label>
        <input type="email" name="email" required>

        <label>Subject</label>
        <input type="text" name="subject" required>

        <label>Your Message</label>
        <textarea name="message" required></textarea>

        <button type="submit" class="contact-submit">Send Message</button>
    </form>

    <div style="text-align:center;">
        <a href="Index.php" class="back-btn">Back to Home</a>
    </div>

</div>

</body>
</html>
