<?php
session_start();

$error = '';
$redirect = $_GET['redirect'] ?? 'Index.php'; // default redirect

// Database connection
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "garden";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username && $password) {
        $stmt = $conn->prepare("SELECT ID, UserName, Password FROM Customers WHERE UserName = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            if (password_verify($password, $row['Password'])) {
                $_SESSION['username'] = $row['UserName'];
                $_SESSION['user_id'] = $row['ID']; // store user_id for account page
                header("Location: $redirect"); // redirect to intended page
                exit;
            } else {
                $error = "Invalid username or password.";
            }
        } else {
            $error = "Invalid username or password.";
        }

        $stmt->close();
    } else {
        $error = "Please enter both username and password.";
    }
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="CSS/styles.css">
    <style>
        body { 
            margin: 0; 
            height: 100vh; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
        }
        .container {
            width: 450px; 
            padding: 30px;
            background: #59a765ff; 
            border-radius: 5px; 
            color: #000;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        }
        .error { color: red; }
        input[type="text"], input[type="password"] {
            width: 100%; 
            padding: 8px; 
            margin: 5px 0;
            box-sizing: border-box;
        }
        button {
            width: 100%; 
            padding: 10px; 
            background: #15472cff; 
            color: white; 
            border: none; 
            cursor: pointer;
            font-weight: bold;
            border-radius: 4px;
        }
        button:hover { background: #066e31ff; }
        label { display: block; margin-top: 10px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h2 style="text-align:center;">Login</h2>
        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <form method="post" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required autocomplete="off">

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required autocomplete="off"><br><br>

            <button type="submit">Login</button>
        </form>
        <p style="text-align:center; margin-top:10px;">
            Don't have an account? <a href="Registar.php">Register</a>
        </p>
    </div>
</body>
</html>
