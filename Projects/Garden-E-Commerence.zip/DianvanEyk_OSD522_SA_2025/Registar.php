<?php
session_start();

$error = '';
$success = '';

// Database connection details
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "garden";

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        // Check if username already exists in Customers table
        $stmt = $conn->prepare("SELECT UserName FROM Customers WHERE UserName = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Username already taken.";
        } else {
            // Hash password before saving
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert new user into Customers table
            $insertStmt = $conn->prepare("INSERT INTO Customers (UserName, Password) VALUES (?, ?)");
            $insertStmt->bind_param("ss", $username, $hashedPassword);

            if ($insertStmt->execute()) {
                $success = "Registration successful! You can now <a href='Login.php'>log in</a>.";
            } else {
                $error = "Error registering user. Please try again.";
            }

            $insertStmt->close();
        }

        $stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <style>
    body { 
        margin: 0; 
        height: 100vh; 
        display: flex; 
        justify-content: center; 
        align-items: center; 
    }
    .register-container {
        width: 450px; 
        padding: 30px;
        background: #59a765ff; 
        border-radius: 5px; 
        color: #000;
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }
    .error { color: red; }
    .success { color: black; }
    input[type="text"], input[type="password"] {
        width: 100%; 
        padding: 8px; 
        margin: 5px 0;
        box-sizing: border-box;
    }
    button {
        width: 100%; 
        padding: 10px; 
        background: #15472cff; 
        color: white; 
        border: none; 
        cursor: pointer;
        font-weight: bold;
        border-radius: 4px;
        box-sizing: border-box;
    }
    button:hover { 
        background: #066e31ff;
    }
    label { 
        display: block; 
        margin-top: 10px; 
        font-weight: bold;
    }
    </style>
    <link rel="stylesheet" href="CSS/styles.css">
</head>
<body>
    <div class="register-container">
        <h2 style="text-align:center;">Register</h2>
        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <?php if ($success): ?>
            <p class="success"><?= $success ?></p>
        <?php endif; ?>
        <form method="post" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required autocomplete="off" 
                   pattern="[A-Za-z0-9]{3,20}" 
                   title="Username must be 3-20 characters, letters and numbers only">

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required autocomplete="off"
                   pattern=".{6,}" 
                   title="Password must be at least 6 characters"><br><br>

            <button type="submit">Register</button>
        </form>
        <p style="text-align:center; margin-top:10px;">
            Already have an account? <a href="Login.php">Login</a>
        </p>
    </div>
</body>
</html>
