<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['cart'][1] = ($_SESSION['cart'][1] ?? 0) + 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Rose Bush - Heckers Garden Centre</title>
<link rel="stylesheet" href="CSS/styles.css">
</head>
<body>

<a class="back-btn" href="store.php">⬅ Back to Store</a>

<div class="product-page">
    <img src="Media/rose_bush.jpg" class="product-image" alt="Rose Bush">
    <h1>Rose Bush</h1>
    <p>A beautiful rose bush perfect for gardens and patios.</p>
    <p><strong>Price: R350</strong></p>


    <form method="post">
        <button class="addcart-btn">Add to Cart</button>
    </form>
</div>

</body>
</html>
