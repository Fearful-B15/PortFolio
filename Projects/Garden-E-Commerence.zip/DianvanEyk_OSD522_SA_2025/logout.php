<?php
session_start();

// Clear all session data
session_unset();
session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logged Out - Heckers Garden Centre</title>
    <link rel="stylesheet" href="CSS/styles.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .message-box {
            background: white;
            padding: 30px 50px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            text-align: center;
        }
        .message-box h2 {
            margin-bottom: 20px;
        }
        .message-box a {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: #15472c;
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 6px;
        }
        .message-box a:hover {
            background: #0e351f;
        }
    </style>
</head>
<body>

<div class="message-box">
    <h2>Successfully Logged Out</h2>
    <p>You have been logged out of your account.</p>
    <a href="Index.php">Go to Homepage</a>
</div>

</body>
</html>
