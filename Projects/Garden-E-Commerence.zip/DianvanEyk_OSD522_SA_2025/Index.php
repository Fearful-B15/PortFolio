<?php
session_start();

// Check if user is logged in
$isLoggedIn = isset($_SESSION['username']);
$username = $isLoggedIn ? $_SESSION['username'] : "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Heckers Garden Centre</title>

    <!-- External CSS -->
    <link rel="stylesheet" href="CSS/styles.css">
</head>
<body>

<!-- Header -->
<header class="header">
    <img src="Media/HeckersGardenLogo.png" alt="Heckers Garden Centre Logo" class="logo">

    <?php if ($isLoggedIn): ?>
        <p class="welcome-user">
            Welcome, <strong><?= htmlspecialchars($username) ?></strong>!<br><br>
            <p class="welcome-user"></p>
            <a href="Login.php" class="header-btn">Login</a> 
            <a href="Registar.php" class="header-btn">Register</a>
            <a href="logout.php" class="header-btn logout">Logout</a>
        </p>
    <?php else: ?>


    <?php endif; ?>
</header>

<!-- Navigation-->
<nav class="nav-buttons">
    <button onclick="location.href='Store.php'">Shop</button>
    <button onclick="location.href='Promo.php'">Promotions</button>
    <button onclick="location.href='About us.php'">About Us</button>
    <button onclick="location.href='Pet.php'">Pet</button>
    <button onclick="location.href='FAQ.php'">FAQ</button>
</nav>

<!-- Image Carousel with sliders -->
<div class="slider">
    <div class="slides">
        <img src="Media/1.jpg" alt="Slide 1">
        <img src="Media/2.jpeg" alt="Slide 2">
        <img src="Media/3.jpg" alt="Slide 3">
        <img src="Media/4.jpg" alt="Slide 4">
    </div>

    <!-- Arrows -->
    <span class="prev">&#10094;</span>
    <span class="next">&#10095;</span>
</div>

<!-- Welcome Text -->
<p class="homepage-message">
    Welcome to Heckers Garden Centre <br>
    your friendly, local destination for plants, garden supplies, pet essentials, and seasonal offers.<br>
    Explore our departments and discover what we have in store for you today!
</p>

<!-- Carousel Script -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const slides = document.querySelector('.slides');
    const images = document.querySelectorAll('.slides img');
    const prev = document.querySelector('.prev');
    const next = document.querySelector('.next');

    let index = 0;

    function showSlide(i) {
        index = (i + images.length) % images.length;
        slides.style.transform = `translateX(${-index * 100}%)`;
    }

    function nextSlide() { showSlide(index + 1); }
    function prevSlide() { showSlide(index - 1); }

    next.addEventListener('click', nextSlide);
    prev.addEventListener('click', prevSlide);

    setInterval(nextSlide, 4000);
});
</script>

</body>
</html>
