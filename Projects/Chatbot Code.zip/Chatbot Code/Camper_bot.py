import nltk
from nltk.chat.util import Chat
import tkinter as tk
from tkinter import scrolledtext

# Download necessary NLTK data
nltk.download('punkt')


# Define chatbot responses to the users
pairs = [
    [
        r"products|items|soods|stock|supplies|1",
        ["We have a wide range of camping products? Tents:R1250 \n Portable stoves:R750 \n Mugs or cups:R25 \n Insect repellent:R140\n Hammock:R250\n You name it we have it"]
    ],
    [
        r"sales|promotions|specials|2",
        ["We have a sale on tents and climbing gear up to 35 percent off until the end of August"]
    ],
    [
        r"benefits of club card owners|club card|benefits|3",
        ["We have a sale on tents and climbing gear up to 35 percent off until the end of August"]
    ],
    [
        r"recommendations|best things to buy|beginner campers|expert campers|4",
        ["We recommend getting a medium sized tent alongside a gas stove, pocket knife or multitool, and insect repellent if you're a beginner camper. For more experienced campers, we recommend a solar charger, portable camping shower, and a shade canopy or tarp."]
    ],
    [
        r"quit|goodbye|exit|end|5",
        ["Bye, take care. See you soon."]
    ],
]

# Create a chatbot instance
chatbot = Chat(pairs)

# Function to handle user input
def handle_input(event=None):
    user_input = user_entry.get()
    chat_history.insert(tk.END, f"You: {user_input}\n")
    user_entry.delete(0, tk.END)
    #if statement to end our program when the following are type inside the running code
    if user_input.lower() in ["quit", "goodbye", "exit", "end"]:
        chat_history.insert(tk.END, "Camperbot: Bye, take care. See you soon.\n")
        return
    #When the user inputs this the appropiate response is made
    response = chatbot.respond(user_input)
    chat_history.insert(tk.END, f"Camperbot: {response}\n")

# Create main window
window = tk.Tk()
window.title("Camperbot")

# Create chat history area
chat_history = scrolledtext.ScrolledText(window, wrap=tk.WORD, state='disabled')
chat_history.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

# Create user entry field
user_entry = tk.Entry(window)
user_entry.pack(padx=10, pady=10, fill=tk.X, expand=True)
user_entry.bind("<Return>", handle_input)

# Create send button
send_button = tk.Button(window, text="Send", command=handle_input)
send_button.pack(padx=10, pady=10)

# Initial message
chat_history.config(state='normal')
chat_history.insert(tk.END, "Hi, I'm the Camperbot. How can I assist you today? Type option of the option below or the number assigned to it..\n 1.Supplies \n 2.Sales\n 3.Benefits of a club card owner \n 4.Recommendation \n 5.quit ")
chat_history.config(state='normal')

# Start the Tkinter event loop
window.mainloop()